document.addEventListener("DOMContentLoaded", function(){
  $('.menu-btn').on('click', function(e) {
  e.preventDefault();
  $('.menu').toggleClass('menu_active');
});
  $('.yr-liza').on('click', function(e) {
  e.preventDefault();
  $('.fiz-lica').removeClass('client-liza-active');
  $('.yr-liza').addClass('client-liza-active');
  $('.tab-content-yr').removeClass('tab-content-yr-none');
  $('.tab-content-yr').addClass('tab-content-yr-block');
  $('.tab-content-fiz').removeClass('tab-content-fiz-block');
  $('.tab-content-fiz').addClass('tab-content-fiz-none');
});
  $('.fiz-lica').on('click', function(e) {
  e.preventDefault();
  $('.yr-liza').removeClass('client-liza-active');
  $('.fiz-lica').addClass('client-liza-active');
  $('.tab-content-fiz').removeClass('tab-content-fiz-none');
  $('.tab-content-fiz').addClass('tab-content-fiz-block');
  $('.tab-content-yr').removeClass('tab-content-yr-block');
  $('.tab-content-yr').addClass('tab-content-yr-none');
});
  $('.caruosel-client-1').on('click', function(e) {
  e.preventDefault();
  $('.client-desc-1').addClass('client-desc-active');
  $('.client-desc-1').removeClass('client-desc-none');
  $('.client-desc-2').removeClass('client-desc-active');
  $('.client-desc-2').addClass('client-desc-none');
  $('.client-desc-3').removeClass('client-desc-active');
  $('.client-desc-3').addClass('client-desc-none');
  $('.client-desc-4').removeClass('client-desc-active');
  $('.client-desc-4').addClass('client-desc-none');
  $('.client-desc-5').removeClass('client-desc-active');
  $('.client-desc-5').addClass('client-desc-none');
  $('.client-desc-6').removeClass('client-desc-active');
  $('.client-desc-6').addClass('client-desc-none');
  $('.client-desc-7').removeClass('client-desc-active');
  $('.client-desc-7').addClass('client-desc-none');
  $('.client-desc-8').removeClass('client-desc-active');
  $('.client-desc-8').addClass('client-desc-none');
  $('.client-desc-9').removeClass('client-desc-active');
  $('.client-desc-9').addClass('client-desc-none');
});
  $('.caruosel-client-2').on('click', function(e) {
  e.preventDefault();
  $('.client-desc-2').addClass('client-desc-active');
  $('.client-desc-2').removeClass('client-desc-none');
  $('.client-desc-1').removeClass('client-desc-active');
  $('.client-desc-1').addClass('client-desc-none');
  $('.client-desc-3').removeClass('client-desc-active');
  $('.client-desc-3').addClass('client-desc-none');
  $('.client-desc-4').removeClass('client-desc-active');
  $('.client-desc-4').addClass('client-desc-none');
  $('.client-desc-5').removeClass('client-desc-active');
  $('.client-desc-5').addClass('client-desc-none');
  $('.client-desc-6').removeClass('client-desc-active');
  $('.client-desc-6').addClass('client-desc-none');
  $('.client-desc-7').removeClass('client-desc-active');
  $('.client-desc-7').addClass('client-desc-none');
  $('.client-desc-8').removeClass('client-desc-active');
  $('.client-desc-8').addClass('client-desc-none');
  $('.client-desc-9').removeClass('client-desc-active');
  $('.client-desc-9').addClass('client-desc-none');
});
  $('.caruosel-client-3').on('click', function(e) {
  e.preventDefault();
  $('.client-desc-3').addClass('client-desc-active');
  $('.client-desc-3').removeClass('client-desc-none');
  $('.client-desc-1').removeClass('client-desc-active');
  $('.client-desc-1').addClass('client-desc-none');
  $('.client-desc-2').removeClass('client-desc-active');
  $('.client-desc-2').addClass('client-desc-none');
  $('.client-desc-4').removeClass('client-desc-active');
  $('.client-desc-4').addClass('client-desc-none');
  $('.client-desc-5').removeClass('client-desc-active');
  $('.client-desc-5').addClass('client-desc-none');
  $('.client-desc-6').removeClass('client-desc-active');
  $('.client-desc-6').addClass('client-desc-none');
  $('.client-desc-7').removeClass('client-desc-active');
  $('.client-desc-7').addClass('client-desc-none');
  $('.client-desc-8').removeClass('client-desc-active');
  $('.client-desc-8').addClass('client-desc-none');
  $('.client-desc-9').removeClass('client-desc-active');
  $('.client-desc-9').addClass('client-desc-none');
});
  $('.caruosel-client-4').on('click', function(e) {
  e.preventDefault();
  $('.client-desc-4').addClass('client-desc-active');
  $('.client-desc-4').removeClass('client-desc-none');
  $('.client-desc-1').removeClass('client-desc-active');
  $('.client-desc-1').addClass('client-desc-none');
  $('.client-desc-2').removeClass('client-desc-active');
  $('.client-desc-2').addClass('client-desc-none');
  $('.client-desc-3').removeClass('client-desc-active');
  $('.client-desc-3').addClass('client-desc-none');
  $('.client-desc-5').removeClass('client-desc-active');
  $('.client-desc-5').addClass('client-desc-none');
  $('.client-desc-6').removeClass('client-desc-active');
  $('.client-desc-6').addClass('client-desc-none');
  $('.client-desc-7').removeClass('client-desc-active');
  $('.client-desc-7').addClass('client-desc-none');
  $('.client-desc-8').removeClass('client-desc-active');
  $('.client-desc-8').addClass('client-desc-none');
  $('.client-desc-9').removeClass('client-desc-active');
  $('.client-desc-9').addClass('client-desc-none');
});
  $('.caruosel-client-5').on('click', function(e) {
  e.preventDefault();
  $('.client-desc-5').addClass('client-desc-active');
  $('.client-desc-5').removeClass('client-desc-none');
  $('.client-desc-1').removeClass('client-desc-active');
  $('.client-desc-1').addClass('client-desc-none');
  $('.client-desc-2').removeClass('client-desc-active');
  $('.client-desc-2').addClass('client-desc-none');
  $('.client-desc-3').removeClass('client-desc-active');
  $('.client-desc-3').addClass('client-desc-none');
  $('.client-desc-4').removeClass('client-desc-active');
  $('.client-desc-4').addClass('client-desc-none');
  $('.client-desc-6').removeClass('client-desc-active');
  $('.client-desc-6').addClass('client-desc-none');
  $('.client-desc-7').removeClass('client-desc-active');
  $('.client-desc-7').addClass('client-desc-none');
  $('.client-desc-8').removeClass('client-desc-active');
  $('.client-desc-8').addClass('client-desc-none');
  $('.client-desc-9').removeClass('client-desc-active');
  $('.client-desc-9').addClass('client-desc-none');
});
  $('.caruosel-client-6').on('click', function(e) {
  e.preventDefault();
  $('.client-desc-6').addClass('client-desc-active');
  $('.client-desc-6').removeClass('client-desc-none');
  $('.client-desc-1').removeClass('client-desc-active');
  $('.client-desc-1').addClass('client-desc-none');
  $('.client-desc-2').removeClass('client-desc-active');
  $('.client-desc-2').addClass('client-desc-none');
  $('.client-desc-3').removeClass('client-desc-active');
  $('.client-desc-3').addClass('client-desc-none');
  $('.client-desc-4').removeClass('client-desc-active');
  $('.client-desc-4').addClass('client-desc-none');
  $('.client-desc-5').removeClass('client-desc-active');
  $('.client-desc-5').addClass('client-desc-none');
  $('.client-desc-7').removeClass('client-desc-active');
  $('.client-desc-7').addClass('client-desc-none');
  $('.client-desc-8').removeClass('client-desc-active');
  $('.client-desc-8').addClass('client-desc-none');
  $('.client-desc-9').removeClass('client-desc-active');
  $('.client-desc-9').addClass('client-desc-none');
});
  $('.caruosel-client-7').on('click', function(e) {
  e.preventDefault();
  $('.client-desc-7').addClass('client-desc-active');
  $('.client-desc-7').removeClass('client-desc-none');
  $('.client-desc-1').removeClass('client-desc-active');
  $('.client-desc-1').addClass('client-desc-none');
  $('.client-desc-2').removeClass('client-desc-active');
  $('.client-desc-2').addClass('client-desc-none');
  $('.client-desc-3').removeClass('client-desc-active');
  $('.client-desc-3').addClass('client-desc-none');
  $('.client-desc-4').removeClass('client-desc-active');
  $('.client-desc-4').addClass('client-desc-none');
  $('.client-desc-5').removeClass('client-desc-active');
  $('.client-desc-5').addClass('client-desc-none');
  $('.client-desc-6').removeClass('client-desc-active');
  $('.client-desc-6').addClass('client-desc-none');
  $('.client-desc-8').removeClass('client-desc-active');
  $('.client-desc-8').addClass('client-desc-none');
  $('.client-desc-9').removeClass('client-desc-active');
  $('.client-desc-9').addClass('client-desc-none');
});
  $('.caruosel-client-8').on('click', function(e) {
  e.preventDefault();
  $('.client-desc-8').addClass('client-desc-active');
  $('.client-desc-8').removeClass('client-desc-none');
  $('.client-desc-1').removeClass('client-desc-active');
  $('.client-desc-1').addClass('client-desc-none');
  $('.client-desc-2').removeClass('client-desc-active');
  $('.client-desc-2').addClass('client-desc-none');
  $('.client-desc-3').removeClass('client-desc-active');
  $('.client-desc-3').addClass('client-desc-none');
  $('.client-desc-4').removeClass('client-desc-active');
  $('.client-desc-4').addClass('client-desc-none');
  $('.client-desc-5').removeClass('client-desc-active');
  $('.client-desc-5').addClass('client-desc-none');
  $('.client-desc-6').removeClass('client-desc-active');
  $('.client-desc-6').addClass('client-desc-none');
  $('.client-desc-7').removeClass('client-desc-active');
  $('.client-desc-7').addClass('client-desc-none');
  $('.client-desc-9').removeClass('client-desc-active');
  $('.client-desc-9').addClass('client-desc-none');
});
  $('.caruosel-client-9').on('click', function(e) {
  e.preventDefault();
  $('.client-desc-9').addClass('client-desc-active');
  $('.client-desc-9').removeClass('client-desc-none');
  $('.client-desc-1').addClass('client-desc-none');
  $('.client-desc-1').removeClass('client-desc-active');
  $('.client-desc-2').removeClass('client-desc-active');
  $('.client-desc-2').addClass('client-desc-none');
  $('.client-desc-3').removeClass('client-desc-active');
  $('.client-desc-3').addClass('client-desc-none');
  $('.client-desc-4').removeClass('client-desc-active');
  $('.client-desc-4').addClass('client-desc-none');
  $('.client-desc-5').removeClass('client-desc-active');
  $('.client-desc-5').addClass('client-desc-none');
  $('.client-desc-6').removeClass('client-desc-active');
  $('.client-desc-6').addClass('client-desc-none');
  $('.client-desc-7').removeClass('client-desc-active');
  $('.client-desc-7').addClass('client-desc-none');
  $('.client-desc-8').removeClass('client-desc-active');
  $('.client-desc-8').addClass('client-desc-none');
});
    $( document ).ready(function() {
  new WOW().init();
});
  $('.btn-readme').on('click', function(e) {
        e.preventDefault();
        $('.readme-mobile').addClass("readme-active");
        $('.btn-readme').addClass("btn-readme-none");
    });
  $('.btn-readme-2').on('click', function(e) {
        e.preventDefault();
        $('.readme-mobile-2').addClass("readme-active-2");
        $('.btn-readme-2').addClass("btn-readme-none");
    });
  $('.btn-readme-3').on('click', function(e) {
        e.preventDefault();
        $('.readme-mobile-3').addClass("readme-active-3");
        $('.btn-readme-3').addClass("btn-readme-none");
    });
  $('.btn-readme-4').on('click', function(e) {
        e.preventDefault();
        $('.readme-mobile-4').addClass("readme-active-4");
        $('.btn-readme-4').addClass("btn-readme-none");
    });
  $('.btn-readme-5').on('click', function(e) {
        e.preventDefault();
        $('.prise-readme-mobile').addClass("prise-readme-mobile-active");
        $('.btn-readme-5').addClass("btn-readme-none");
    });
  $(document).ready(function() {
  let a = 0;
  let b = 0;
  let sm = 0;
  let s = 0;
  function checkWidth() {
    var windowWidth = $('body').innerWidth(),
        elem = $(".number-bullets"); 
                                    
    if(windowWidth < 992){
      if (a==0) {
          let h = '<div id="blog-del"><div class="copy">© Юридический кабинет Ани Манташян, 2020.</div></div>';
          document.getElementById('copy-bottom-mobile').insertAdjacentHTML('beforeend', h);
          let c = '<ol id="idicator-del" class="carousel-indicators d-block-mobile"><li data-target="#carouselExampleIndicators11" data-slide-to="0" class="active"></li><li data-target="#carouselExampleIndicators11" data-slide-to="1"></li><li data-target="#carouselExampleIndicators11" data-slide-to="2"></li><li data-target="#carouselExampleIndicators11" data-slide-to="3"></li><li data-target="#carouselExampleIndicators11" data-slide-to="4"></li><li data-target="#carouselExampleIndicators11" data-slide-to="5"></li><li data-target="#carouselExampleIndicators11" data-slide-to="6"></li></ol>';
          document.getElementById('inner-mobile').insertAdjacentHTML('beforeend', c);
          a = 1;
          b = 1;
        }
      }
      else{
        if (b==1) {
            document.getElementById('blog-del').remove();
            document.getElementById('idicator-del').remove();
            a = 0;
            b = 0;
          }
      }
      if (windowWidth < 768) {
        if (sm==0) {
          let slidermobile = '<div id="block-slider-mobile" class="carousel-inner row w-100 mx-auto"><div class="carousel-item col-md-4 active"><div class="card mb-2"><div class="card-body"><p class="service"><img src="img/service-icon.svg" alt="">Услуги физическим и юридическим лицам</p><h4 class="card-title font-weight-bold">Разовые консультации</h4><p class="card-text">При возникновении спорной ситуации компания предлагает разово обратиться к нашим специалистам для разъяснения. Консультация включает в себя ответы по любым правовым вопросам, а также подготовку письменного заключения с предложением нескольких вариантов разрешения проблемы, подготовку «Legal opinion» по правовым вопросам.</p><p class="price">3 500 руб.</p></div></div></div><div class="carousel-item col-md-4"><div class="card mb-2"><div class="card-body"><p class="service"><img src="img/service-icon.svg" alt="">Услуга физическим и юридическим лицам</p><h4 class="card-title font-weight-bold">Подготовка гражданско-правовых договоров</h4><p class="card-text">В данную услугу входит разработка, корректировка и заключение договоров по различным областям права: инвестиционные договоры, договор о совместной деятельности, договоры аренды, поставки, подряда, брачные соглашения, соглашения о разделе имущества и др. Оказываем поддержку в обеспечении правовой помощи при проведении переговоров, а также процедур заключения договоров.</p><p class="price ">от 15 000 руб.</p></div></div></div><div class="carousel-item col-md-4"><div class="card mb-2"><div class="card-body"><p class="service"><img src="img/service-icon.svg" alt="">Услуги юридическим лицам</p><h4 class="card-title font-weight-bold">Регистрация и реорганизация</h4><p class="card-text">Предлагаем помощь в: участии в корпоративных переговорах, процедурах по продаже бизнеса, подготовке пакетов корпоративных документов, подготовке внутренних локальных документов заказчика.</p><p class="price">от 15 000 руб.</p></div></div></div><div class="carousel-item col-md-4"><div class="card mb-2"><div class="card-body"><p class="service"><img src="img/service-icon.svg" alt="">Услуги физическим и юридическим лицам</p><h4 class="card-title font-weight-bold">Арбитраж</h4><p class="card-text">Анализ гражданско-правовых и процессуальных документов по судебным делам различной степени сложности. Составление заявлений в арбитражный суд, подготовка апелляционных, кассационных и надзорных жалоб в Арбитражный и Верховный суд (без участия в процессе).</p><p class="price">от 50 000 руб.</p></div></div></div><div class="carousel-item col-md-4"><div class="card mb-2"><div class="card-body"><p class="service"><img src="img/service-icon.svg" alt="">Услуги юридическим лицам</p><h4 class="card-title font-weight-bold">Правовое сопровождение деятельности компании (аутсорсинг)</h4><p class="card-text">Ведение операционной деятельности компании для решения правовых вопросов. Работа по системе «под ключ», составление отдельных процессуальных и корпоративных документов по запросу клиента. Участие в судебных заседаниях судов всех инстанций. Консультации сотрудникам и руководству фирмы.</p><p class="price">от 40 000 руб.</p></div></div></div></div>';
          document.getElementById('price-slider-mobile').insertAdjacentHTML('beforeend', slidermobile);
          sm = 1;
        }
      }
      else{
        if (sm==1) {
          document.getElementById('block-slider-mobile').remove();
          sm = 0;
        }
      }
  }
  checkWidth(); 
  $(window).resize(function(){
    checkWidth();
  });
});
  let forms = $('.needs-validation');
    let validation = Array.prototype.filter.call(forms, function(form) {
        form.addEventListener('submit', function(event) {
            event.preventDefault();
                $.ajax({
                    url: 'form.php',
                    type: 'POST',
                    data: $(this).serialize(),
                    success: function() {
                        $('#callBack').modal('hide');
                        $('#contactForm').trigger('reset');
                        $('#response').modal('show');
                    }
                });
            });
    });
    let forms2 = $('.needs-validation-2');
    let validation2 = Array.prototype.filter.call(forms2, function(form) {
        form.addEventListener('submit', function(event) {
            event.preventDefault();
                $.ajax({
                    url: 'form2.php',
                    type: 'POST',
                    data: $(this).serialize(),
                    success: function() {
                        $('#callBack').modal('hide');
                        $('#contactForm-2').trigger('reset');
                        $('#response').modal('show');
                    }
                });
            });
    });
});
$('.carousel.carousel-multi-item.v-2 .carousel-item').each(function(){
  var next = $(this).next();
  if (!next.length) {
    next = $(this).siblings(':first');
  }
  next.children(':first-child').clone().appendTo($(this));

  for (var i=0;i<4;i++) {
    next=next.next();
    if (!next.length) {
      next=$(this).siblings(':first');
    }
    next.children(':first-child').clone().appendTo($(this));
  }
});
$('.scrollto a').on('click', function() {

    let href = $(this).attr('href');

    $('html, body').animate({
        scrollTop: $(href).offset().top
    }, {
        duration: 370,   
        easing: "linear" 
    });

    return false;
});